-- AlterTable
ALTER TABLE "seller" ALTER COLUMN "is_manager" SET DEFAULT false;
